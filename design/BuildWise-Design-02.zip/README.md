# BuildWise Design 02 Blueprint

Open http://localhost:5180/design-two#/dashboard for the second visual direction, or /design-two#/brand for the logo and all 20 primary screens. The first direction remains at /#/dashboard.

Design 02 uses midnight blue (#14233B), orange (#FF6B35), cloud (#F3F5F9) and white. A horizontal navigation bar and narrow tool rail replace the original sidebar. The new dashboard combines a blueprint illustration, a next-action queue, a metrics strip, recent requests and a quotation pipeline. Service cards, forms, document previews, settings and authentication screens share the updated style.

The second logo uses an isometric block and structural linework. Editable vector assets are wwwroot/brand/buildwise-logo-two.svg and wwwroot/brand/buildwise-mark-two.svg. Raster screen exports are in the screens folder.

All underlying interactions use the existing local prototype: customers, catalogue entries, clarification answers, scope review, quotations and retained approved revisions. Authentication, AI, persistent server storage and email delivery are not connected. No demo labels are displayed. Both designs use the same browser-local workspace records.

Validation passed for all primary routes, search, scope approval, quotation approval, retained revisions and mobile overflow. The original build and the new Razor page compile without warnings or errors.
